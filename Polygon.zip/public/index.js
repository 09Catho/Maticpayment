    // index.js (client-side script)

    // Replace with your actual Polygon wallet address
    const walletAddress = "0xYourActualPolygonWalletAddress"; 

    // Update wallet address on the page
    document.getElementById('walletAddress').innerText = walletAddress;

    // Add event listener to verify transaction
    document.getElementById('submit').addEventListener('click', async () => {
        const transactionHash = document.getElementById('transactionHash').value.trim();
        const responseDiv = document.getElementById('response');

        responseDiv.innerHTML = "Verifying transaction...";

        if (!transactionHash) {
            responseDiv.innerHTML = "<p style='color:red;'>Please enter a valid transaction hash.</p>";
            return;
        }

        try {
            const response = await fetch('/verify-transaction', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ transactionHash }),
            });

            const data = await response.json();

            if (data.success) {
                responseDiv.innerHTML = `<p>Transaction successful! Your transaction ID: <strong>${data.transactionId}</strong></p>`;
            } else {
                responseDiv.innerHTML = `<p style="color:red;">${data.message}</p>`;
            }
        } catch (error) {
            responseDiv.innerHTML = `<p style="color:red;">An error occurred. Please try again later.</p>`;
        }
    });