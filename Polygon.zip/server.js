const express = require('express');
const { ethers } = require('ethers'); // Ensure ethers is properly imported
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Set up your wallet address and Matic RPC provider
const provider = new ethers.providers.JsonRpcProvider("https://polygon-rpc.com/");
const vipWalletAddress = "0xYourActualPolygonWalletAddress"; // Replace with your actual wallet address
const vipAmount = ethers.utils.parseEther("10.0"); // Amount of 10 MATIC

app.use(express.json());
app.use(express.static('public'));

// Endpoint to verify transaction
app.post('/verify-transaction', async (req, res) => {
    const { transactionHash } = req.body;

    try {
        // Fetch the transaction details from the blockchain
        const transaction = await provider.getTransaction(transactionHash);

        // Check if the transaction was to your VIP wallet and for the right amount
        if (transaction && transaction.to && transaction.to.toLowerCase() === vipWalletAddress.toLowerCase() && transaction.value.eq(vipAmount)) {
            // Wait for transaction to be confirmed (mining confirmation)
            await transaction.wait();

            // Send back success message
            res.json({ success: true, transactionId: transactionHash });
        } else {
            res.status(400).json({ success: false, message: "Transaction verification failed. Please check the wallet address and amount." });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Internal server error. Please try again later." });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});